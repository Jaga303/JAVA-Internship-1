import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.security.SecureRandom;
import java.util.Base64;

public class trial {
    public static void main(String[] args) throws Exception {
        // Generate a secret key
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128); // Key size in bits
        SecretKey secretKey = keyGenerator.generateKey();

        // Generate an initialization vector (IV)
        byte[] iv = new byte[16]; // IV length must be 16 bytes for AES
        new SecureRandom().nextBytes(iv);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        // Create a cipher object
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); // Algorithm/mode/padding

        // Encrypt the text
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        String plainText = "This is a secret message.";
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes());

        // Encode IV and encrypted bytes to Base64
        String ivBase64 = Base64.getEncoder().encodeToString(iv);
        String encryptedTextBase64 = Base64.getEncoder().encodeToString(encryptedBytes);

        // Decrypt the text
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedTextBase64));
        String decryptedText = new String(decryptedBytes);

        System.out.println("Plain text: " + plainText);
        System.out.println("IV: " + ivBase64); // Show IV for decryption
        System.out.println("Encrypted text: " + encryptedTextBase64);
        System.out.println("Decrypted text: " + decryptedText);
    }
}
